import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes, ConversationHandler
from mistralai import Mistral
import re
from datetime import datetime

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

BOT_TOKEN = "BOT_TOKEN"
ADMIN_ID = ADMIN_ID
MISTRAL_API_KEY = "MISTRAL_API_KEY"
ADMIN_USERNAME = "ADMIN_USERNAME"

CHAT_WITH_AI, WAITING_FOR_ADMIN, ADMIN_CHAT_ACTIVE = range(3)

mistral_client = Mistral(api_key=MISTRAL_API_KEY)

user_sessions = {}
admin_requests = {}
active_admin_chats = {}

SUPPORT_KEYWORDS = [
    'поддержка', 'админ', 'администратор', 'оператор', 
    'человек', 'сотрудник', 'менеджер', 'помощь человека',
    'дай поддержку', 'иди поддержка', 'дай оператора',
    'переключи на человека', 'живой человек', 'реальный человек',
    'дай админа', 'соедини с админом', 'нужен человек',
    'хочу человека', 'требую оператора', 'свяжи с менеджером'
]

class UserSession:
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.messages = []
        self.is_with_admin = False
        self.admin_request_time = None
        self.is_admin_chat_active = False
        self.admin_assigned = None
        self.clothing_only_mode = True
    
    def add_message(self, role: str, content: str):
        self.messages.append({"role": role, "content": content})
        if len(self.messages) > 10:
            self.messages = self.messages[-10:]
    
    def check_clothing_question(self, text: str) -> bool:
        clothing_keywords = [
            'одежда', 'платье', 'рубашка', 'футболка', 'брюки', 'джинсы',
            'костюм', 'пиджак', 'куртка', 'пальто', 'шуба', 'пуховик',
            'юбка', 'блузка', 'свитер', 'толстовка', 'худи', 'ветровка',
            'белье', 'нижнее белье', 'трусы', 'бюстгальтер', 'носки',
            'колготки', 'чулки', 'гольфы', 'майка', 'шорты', 'бермуды',
            'панама', 'шляпа', 'кепка', 'шапка', 'берет', 'кеды', 'кроссовки',
            'туфли', 'ботинки', 'сапоги', 'сандали', 'лоферы', 'мокасины',
            'размер', 'мерка', 'рост', 'обхват', 'талия', 'бедра', 'грудь',
            'материал', 'ткань', 'хлопок', 'шелк', 'шерсть', 'синтетика',
            'кожа', 'замша', 'джинса', 'флис', 'вельвет', 'кашемир',
            'стирка', 'уход', 'глажка', 'химчистка', 'цвет', 'расцветка',
            'принт', 'рисунок', 'узоры', 'фасон', 'крой', 'силуэт',
            'бренд', 'марка', 'производитель', 'магазин', 'бутик',
            'цена', 'стоимость', 'скидка', 'распродажа', 'акция',
            'мода', 'тренд', 'стиль', 'лук', 'образ', 'гардероб',
            'комплект', 'ансамбль', 'сочетание', 'комбинация',
            'сезон', 'лето', 'зима', 'осень', 'весна', 'демисезон',
            'формаль', 'официаль', 'деловой', 'повседнев', 'спортив',
            'вечер', 'свадьба', 'праздник', 'коктейль', 'выход'
        ]
        
        text_lower = text.lower()
        
        if any(word in text_lower for word in ['танцор', 'танцую', 'танец', 'dancer', 'танцевать']):
            return True
        
        for keyword in clothing_keywords:
            if keyword in text_lower:
                return True
        
        return False

def check_support_request(text: str) -> bool:
    text_lower = text.lower()
    for keyword in SUPPORT_KEYWORDS:
        if keyword in text_lower:
            return True
    return False

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = update.effective_user.id
    
    welcome_text = f"Привет, {user.first_name}! 👋\n\nЯ ваш ИИ-ассистент по вопросам одежды."
    
    if user_id not in user_sessions:
        user_sessions[user_id] = UserSession(user_id)
    else:
        session = user_sessions[user_id]
        session.is_with_admin = False
        session.is_admin_chat_active = False
        session.admin_assigned = None
    
    keyboard = [[InlineKeyboardButton("Завершить чат", callback_data='end_chat')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(welcome_text)
    await update.message.reply_text(
        "Я могу ответить только на вопросы, связанные с одеждой, модой и гардеробом.\n\n"
        "Если нужна помощь по другим вопросам или хотите поговорить с человеком, "
        "просто напишите 'поддержка' или 'админ'.",
        reply_markup=reply_markup
    )
    
    return CHAT_WITH_AI

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_message = update.message.text
    
    if user_id in active_admin_chats.values():
        admin_id = [k for k, v in active_admin_chats.items() if v == user_id][0]
        await forward_user_to_admin(update, context, user_id, admin_id, user_message)
        return ADMIN_CHAT_ACTIVE
    
    if check_support_request(user_message):
        return await request_admin_support(update, context, user_message)
    
    if user_id not in user_sessions:
        user_sessions[user_id] = UserSession(user_id)
    
    session = user_sessions[user_id]
    
    if session.is_with_admin and not session.is_admin_chat_active:
        await update.message.reply_text("⏳ Ваш запрос еще не взят администратором. Ожидайте...")
        return WAITING_FOR_ADMIN
    
    if not session.check_clothing_question(user_message):
        await update.message.reply_text(
            "⚠️ Я могу отвечать только на вопросы, связанные с одеждой, модой и гардеробом.\n\n"
            "Примеры вопросов:\n"
            "• Какой размер мне подойдет?\n"
            "• Как ухаживать за шерстяным свитером?\n"
            "• Что надеть на свадьбу?\n"
            "• Какие есть тренды этого сезона?\n\n"
            "Если у вас другой вопрос или нужна помощь администратора, "
            "напишите 'поддержка'."
        )
        return CHAT_WITH_AI
    
    if any(word in user_message.lower() for word in ['танцор', 'танцую', 'танец', 'dancer']):
        await handle_dancer_request(update, context, user_message)
        return CHAT_WITH_AI
    
    session.add_message("user", user_message)
    
    try:
        ai_response = await get_mistral_response(session.messages)
        session.add_message("assistant", ai_response)
        await update.message.reply_text(ai_response)
    except Exception as e:
        logger.error(f"Ошибка Mistral: {e}")
        await update.message.reply_text("Извините, произошла ошибка при обработке вопроса об одежде.")
    
    return CHAT_WITH_AI

async def handle_dancer_request(update: Update, context: ContextTypes.DEFAULT_TYPE, user_message: str):
    response = (
        "💃 **Информация о танцоре:**\n\n"
        "Танцоры часто носят специальную одежду для тренировок и выступлений:\n\n"
        "1. **Для тренировок:**\n"
        "   • Обтягивающая одежда (леггинсы, топы)\n"
        "   • Спортивные купальники\n"
        "   • Балетки или джазовки\n"
        "   • Наколенники и защита\n\n"
        "2. **Для выступлений:**\n"
        "   • Сценические костюмы\n"
        "   • Танцевальные платья\n"
        "   • Специальная обувь (пуанты, характерные туфли)\n"
        "   • Аксессуары (перчатки, головные уборы)\n\n"
        "Материалы обычно эластичные и дышащие: лайкра, спандекс, хлопок с добавлением эластана."
    )
    await update.message.reply_text(response, parse_mode='Markdown')

async def get_mistral_response(messages_history):
    try:
        system_message = {
            "role": "system",
            "content": (
                "Ты консультант по одежде и моде. Отвечай ТОЛЬКО на вопросы, связанные с:\n"
                "1. Одеждой, обувью, аксессуарами\n"
                "2. Размерами и подбором одежды\n"
                "3. Уходом за одеждой\n"
                "4. Модными трендами\n"
                "5. Сочетанием вещей\n"
                "6. Стилем и образами\n\n"
                "На все остальные вопросы отвечай: 'Я могу помочь только с вопросами об одежде. "
                "Для других вопросов напишите \"поддержка\" для связи с администратором.'"
            )
        }
        
        full_messages = [system_message] + messages_history[-9:]
        
        response = mistral_client.chat.complete(
            model="mistral-tiny",
            messages=full_messages,
            temperature=0.7,
            max_tokens=500
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        logger.error(f"Mistral API error: {e}")
        return "Извините, не удалось обработать запрос об одежде."

async def request_admin_support(update: Update, context: ContextTypes.DEFAULT_TYPE, user_message: str):
    user_id = update.effective_user.id
    
    if user_id not in user_sessions:
        user_sessions[user_id] = UserSession(user_id)
    
    session = user_sessions[user_id]
    
    if session.is_with_admin:
        if session.is_admin_chat_active:
            await update.message.reply_text("✅ Вы уже общаетесь с администратором.")
            return ADMIN_CHAT_ACTIVE
        else:
            await update.message.reply_text("⏳ Ваш запрос уже отправлен администратору и ожидает ответа.")
            return WAITING_FOR_ADMIN
    
    session.is_with_admin = True
    session.admin_request_time = datetime.now()
    
    admin_requests[user_id] = {
        'user_id': user_id,
        'username': update.effective_user.username,
        'first_name': update.effective_user.first_name,
        'request': user_message,
        'chat_id': update.effective_chat.id,
        'message_id': update.message.message_id,
        'status': 'pending',
        'can_cancel': True
    }
    
    await update.message.reply_text(
        "✅ Запрос на поддержку принят! Ожидайте ответа администратора.\n\n"
        "Чтобы отменить запрос, нажмите кнопку ниже.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Отменить запрос", callback_data='cancel_request')]
        ])
    )
    
    await send_admin_notification(context, user_id, user_message)
    
    return WAITING_FOR_ADMIN

async def send_admin_notification(context, user_id: int, user_message: str):
    request_info = admin_requests[user_id]
    
    admin_message = (
        f"🔔 НОВЫЙ ЗАПРОС НА ПОДДЕРЖКУ!\n\n"
        f"👤 Пользователь: @{request_info['username'] or 'без username'}\n"
        f"📛 Имя: {request_info['first_name']}\n"
        f"🆔 ID: {user_id}\n"
        f"💬 Chat ID: {request_info['chat_id']}\n"
        f"📝 Сообщение: {user_message}\n\n"
        f"⏰ Время запроса: {datetime.now().strftime('%H:%M:%S')}"
    )
    
    keyboard = [
        [InlineKeyboardButton("✅ Взять запрос", callback_data=f'accept_request_{user_id}')],
        [InlineKeyboardButton("❌ Отклонить запрос", callback_data=f'reject_request_{user_id}')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        sent_message = await context.bot.send_message(
            chat_id=ADMIN_ID,
            text=admin_message,
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
        admin_requests[user_id]['admin_notif_id'] = sent_message.message_id
        
    except Exception as e:
        logger.error(f"Не удалось отправить администратору: {e}")

async def accept_request_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = int(query.data.split('_')[-1])
    
    if user_id not in admin_requests:
        await query.edit_message_text("❌ Запрос не найден или уже обработан.")
        return
    
    if admin_requests[user_id]['status'] != 'pending':
        await query.edit_message_text("⚠️ Этот запрос уже обрабатывается.")
        return
    
    admin_requests[user_id]['status'] = 'accepted'
    admin_requests[user_id]['admin_id'] = update.effective_user.id
    admin_requests[user_id]['admin_username'] = update.effective_user.username
    admin_requests[user_id]['can_cancel'] = False
    
    active_admin_chats[update.effective_user.id] = user_id
    
    if user_id in user_sessions:
        session = user_sessions[user_id]
        session.is_admin_chat_active = True
        session.admin_assigned = update.effective_user.id
    
    await query.edit_message_text(
        f"✅ Вы взяли запрос пользователя {user_id}\n\n"
        f"Теперь все ваши сообщения будут отправляться этому пользователю.\n"
        f"Чтобы завершить диалог, отправьте /endchat\n\n"
        f"Первое сообщение пользователя: {admin_requests[user_id]['request']}"
    )
    
    user_message = (
        "👨‍💼 Администратор подключился к чату!\n\n"
        "Теперь вы можете общаться напрямую.\n\n"
        "⚠️ **Внимание:** Теперь вы не можете отменить запрос или вернуться к ИИ, "
        "так как администратор уже взял ваш запрос."
    )
    
    keyboard = [
        [InlineKeyboardButton("Завершить диалог с админом", callback_data='end_admin_chat')]
    ]
    
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text=user_message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        logger.error(f"Не удалось уведомить пользователя: {e}")

async def reject_request_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = int(query.data.split('_')[-1])
    
    if user_id not in admin_requests:
        await query.edit_message_text("❌ Запрос не найден или уже обработан.")
        return
    
    if user_id in admin_requests:
        del admin_requests[user_id]
    
    if user_id in user_sessions:
        user_sessions[user_id].is_with_admin = False
        user_sessions[user_id].is_admin_chat_active = False
    
    await query.edit_message_text(f"❌ Запрос пользователя {user_id} отклонен.")
    
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text="⏳ К сожалению, администратор не смог принять ваш запрос в данный момент. "
                 "Вы можете вернуться к ИИ или попробовать позже."
        )
    except Exception as e:
        logger.error(f"Не удалось уведомить пользователя: {e}")

async def forward_user_to_admin(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int, admin_id: int, message: str):
    try:
        user_info = f"📨 Ответ от Клиента:\n\n{message}"
        await context.bot.send_message(chat_id=admin_id, text=user_info)
    except Exception as e:
        logger.error(f"Ошибка пересылки админу: {e}")

async def forward_admin_to_user(context, user_id: int, message: str):
    try:
        admin_response = f"📨 Ответ от администратора:\n\n{message}"
        await context.bot.send_message(chat_id=user_id, text=admin_response)
    except Exception as e:
        logger.error(f"Ошибка отправки пользователю: {e}")

async def handle_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    
    if update.effective_user.id in active_admin_chats:
        user_id = active_admin_chats[update.effective_user.id]
        
        try:
            await forward_admin_to_user(context, user_id, update.message.text)
            
            if user_id in user_sessions:
                user_sessions[user_id].add_message("admin", update.message.text)
                
        except Exception as e:
            logger.error(f"Ошибка отправки пользователю: {e}")
            await update.message.reply_text(f"❌ Ошибка отправки: {e}")
    else:
        await update.message.reply_text(
            "ℹ️ У вас нет активных чатов с пользователями.\n"
            "Чтобы начать чат, нажмите кнопку 'Взять запрос' в уведомлении о новом запросе."
        )

async def end_admin_chat_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    
    if user_id not in user_sessions:
        await query.edit_message_text("❌ Сессия не найдена.")
        return
    
    session = user_sessions[user_id]
    
    if not session.is_admin_chat_active or not session.admin_assigned:
        await query.edit_message_text("❌ У вас нет активного чата с администратором.")
        return
    
    try:
        admin_id = session.admin_assigned
        await context.bot.send_message(
            chat_id=admin_id,
            text=f"⚠️ Пользователь {user_id} завершил диалог."
        )
        
        if admin_id in active_admin_chats:
            del active_admin_chats[admin_id]
    except:
        pass
    
    session.is_with_admin = False
    session.is_admin_chat_active = False
    session.admin_assigned = None
    
    if user_id in admin_requests:
        del admin_requests[user_id]
    
    keyboard = [[InlineKeyboardButton("Начать заново", callback_data='start_new')]]
    await query.edit_message_text(
        "Диалог с администратором завершен.",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    return ConversationHandler.END

async def admin_end_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    
    admin_id = update.effective_user.id
    
    if admin_id in active_admin_chats:
        user_id = active_admin_chats[admin_id]
        
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text="👨‍💼 Администратор завершил диалог. Спасибо за обращение!"
            )
        except:
            pass
        
        if user_id in user_sessions:
            user_sessions[user_id].is_with_admin = False
            user_sessions[user_id].is_admin_chat_active = False
            user_sessions[user_id].admin_assigned = None
        
        if user_id in admin_requests:
            del admin_requests[user_id]
        
        del active_admin_chats[admin_id]
        
        await update.message.reply_text(f"✅ Диалог с пользователем {user_id} завершен.")
    else:
        await update.message.reply_text("ℹ️ У вас нет активных чатов.")

async def cancel_request_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    
    if user_id not in admin_requests:
        await query.edit_message_text("❌ Запрос не найден или уже обработан.")
        return
    
    if not admin_requests[user_id].get('can_cancel', True):
        await query.edit_message_text("❌ Нельзя отменить запрос, так как администратор уже взял его.")
        return
    
    if admin_requests[user_id]['status'] == 'accepted':
        await query.edit_message_text("❌ Нельзя отменить запрос, так как администратор уже взял его.")
        return
    
    if admin_requests[user_id]['status'] == 'accepted' and 'admin_id' in admin_requests[user_id]:
        try:
            await context.bot.send_message(
                chat_id=admin_requests[user_id]['admin_id'],
                text=f"⚠️ Пользователь {user_id} отменил запрос."
            )
        except:
            pass
    
    if admin_requests[user_id]['status'] == 'pending':
        del admin_requests[user_id]
    
    if user_id in user_sessions:
        user_sessions[user_id].is_with_admin = False
        user_sessions[user_id].is_admin_chat_active = False
    
    keyboard = [[InlineKeyboardButton("Завершить чат", callback_data='end_chat')]]
    await query.edit_message_text(
        "Запрос на поддержку отменен. Вы вернулись к ИИ-ассистенту.",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    return CHAT_WITH_AI

async def back_to_ai_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    
    if user_id not in user_sessions:
        await query.edit_message_text("❌ Сессия не найдена.")
        return
    
    session = user_sessions[user_id]
    
    if user_id in admin_requests:
        if admin_requests[user_id]['status'] == 'accepted':
            await query.edit_message_text("❌ Нельзя вернуться к ИИ, так как администратор уже взял ваш запрос.")
            return WAITING_FOR_ADMIN
    
    if session.is_with_admin and not session.is_admin_chat_active:
        if user_id in admin_requests:
            if admin_requests[user_id]['status'] == 'pending':
                del admin_requests[user_id]
            else:
                await query.edit_message_text("❌ Нельзя вернуться к ИИ, так как администратор уже взял ваш запрос.")
                return WAITING_FOR_ADMIN
        session.is_with_admin = False
    
    keyboard = [[InlineKeyboardButton("Завершить чат", callback_data='end_chat')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text("Возвращаю к ИИ-ассистенту.")
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="Чем могу помочь? Помните, я отвечаю только на вопросы об одежде.",
        reply_markup=reply_markup
    )
    
    return CHAT_WITH_AI

async def end_chat_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    
    if user_id in user_sessions:
        session = user_sessions[user_id]
        if session.is_admin_chat_active and session.admin_assigned:
            try:
                await context.bot.send_message(
                    chat_id=session.admin_assigned,
                    text=f"⚠️ Пользователь {user_id} завершил сессию."
                )
                if session.admin_assigned in active_admin_chats:
                    del active_admin_chats[session.admin_assigned]
            except:
                pass
    
    if user_id in user_sessions:
        del user_sessions[user_id]
    if user_id in admin_requests:
        del admin_requests[user_id]
    
    if query.message:
        await query.edit_message_text("Диалог завершен. Используйте /start")
    
    return ConversationHandler.END

async def start_new_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    return await start(update, context)

async def handle_wa_state_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if user_id not in user_sessions:
        return CHAT_WITH_AI
    
    session = user_sessions[user_id]
    
    if user_id in admin_requests:
        if admin_requests[user_id]['status'] == 'accepted':
            if user_id in active_admin_chats.values():
                admin_id = [k for k, v in active_admin_chats.items() if v == user_id][0]
                await forward_user_to_admin(update, context, user_id, admin_id, update.message.text)
                return ADMIN_CHAT_ACTIVE
            else:
                await update.message.reply_text("⏳ Администратор уже взял ваш запрос. Пожалуйста, ожидайте его ответа.")
                return WAITING_FOR_ADMIN
    
    await update.message.reply_text(
        "⏳ Ваш запрос еще не взят администратором.\n\n"
        "Вы можете:\n"
        "1. Ожидать ответа администратора\n"
        "2. Отменить запрос и вернуться к ИИ",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Отменить запрос", callback_data='cancel_request')],
            [InlineKeyboardButton("Вернуться к ИИ", callback_data='back_to_ai')]
        ])
    )
    
    return WAITING_FOR_ADMIN

async def handle_admin_chat_active(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_message = update.message.text
    
    if user_id in active_admin_chats.values():
        admin_id = [k for k, v in active_admin_chats.items() if v == user_id][0]
        await forward_user_to_admin(update, context, user_id, admin_id, user_message)
        return ADMIN_CHAT_ACTIVE
    
    return ADMIN_CHAT_ACTIVE

def main():
    application = Application.builder().token(BOT_TOKEN).build()
    
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            CHAT_WITH_AI: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message),
                CallbackQueryHandler(end_chat_callback, pattern='^end_chat$'),
                CallbackQueryHandler(cancel_request_callback, pattern='^cancel_request$')
            ],
            WAITING_FOR_ADMIN: [
                CallbackQueryHandler(back_to_ai_callback, pattern='^back_to_ai$'),
                CallbackQueryHandler(cancel_request_callback, pattern='^cancel_request$'),
                CallbackQueryHandler(end_chat_callback, pattern='^end_chat$'),
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_wa_state_message)
            ],
            ADMIN_CHAT_ACTIVE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_admin_chat_active),
                CallbackQueryHandler(end_admin_chat_callback, pattern='^end_admin_chat$'),
                CallbackQueryHandler(end_chat_callback, pattern='^end_chat$')
            ]
        },
        fallbacks=[CommandHandler('cancel', end_chat_callback)],
        allow_reentry=True
    )
    
    application.add_handler(conv_handler)
    
    application.add_handler(CallbackQueryHandler(accept_request_callback, pattern='^accept_request_'))
    application.add_handler(CallbackQueryHandler(reject_request_callback, pattern='^reject_request_'))
    application.add_handler(CommandHandler('endchat', admin_end_chat, filters=filters.User(ADMIN_ID)))
    application.add_handler(MessageHandler(filters.TEXT & filters.Chat(ADMIN_ID) & ~filters.COMMAND, handle_admin_message))
    
    application.add_handler(CallbackQueryHandler(start_new_callback, pattern='^start_new$'))
    
    application.add_error_handler(lambda update, context: logger.error(f"Update {update} caused error {context.error}"))
    
    print("Бот запущен...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()